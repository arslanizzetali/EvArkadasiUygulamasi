package com.example.evarkadasiuygulamasi;

// Author: Halil Ibrahim Kurnaz

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private IlanAdapter ilanAdapter;
    private List<Ilan> ilanList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ilanList = new ArrayList<>();
        // Add some dummy data
        ilanList.add(new Ilan("Ahmet Yılmaz", "İstanbul Üniversitesi", 22, "Erkek", "Bilgisayar Mühendisliği", "İzmir", 41.0082, 28.9784));
        ilanList.add(new Ilan("Elif Kaya", "Boğaziçi Üniversitesi", 20, "Kadın", "Endüstri Mühendisliği", "Ankara", 41.0840, 29.0510));
        ilanList.add(new Ilan("Mehmet Şahin", "İTÜ", 23, "Erkek", "Makine Mühendisliği", "Bursa", 41.1010, 29.0260));
        ilanList.add(new Ilan("Ayşe Özdemir", "Koç Üniversitesi", 21, "Kadın", "Tıp", "Adana", 41.1332, 29.0806));
        
        ilanAdapter = new IlanAdapter(ilanList);
        recyclerView.setAdapter(ilanAdapter);

        Button mapButton = findViewById(R.id.mapButton);
        mapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(intent);
            }
        });
    }
}
package com.example.evarkadasiuygulamasi;

// Author: Halil Ibrahim Kurnaz

public class Ilan {
    private String isim;
    private String okul;
    private int yas;
    private String cinsiyet;
    private String bolum;
    private String memleket;
    private double latitude;
    private double longitude;

    public Ilan(String isim, String okul, int yas, String cinsiyet, String bolum, String memleket, double latitude, double longitude) {
        this.isim = isim;
        this.okul = okul;
        this.yas = yas;
        this.cinsiyet = cinsiyet;
        this.bolum = bolum;
        this.memleket = memleket;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getIsim() {
        return isim;
    }

    public String getOkul() {
        return okul;
    }

    public int getYas() {
        return yas;
    }

    public String getCinsiyet() {
        return cinsiyet;
    }

    public String getBolum() {
        return bolum;
    }

    public String getMemleket() {
        return memleket;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }
}
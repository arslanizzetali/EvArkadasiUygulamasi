package com.example.evarkadasiuygulamasi;

import androidx.fragment.app.FragmentActivity;
import android.location.Location;
import android.os.Bundle;
import com.example.evarkadasiuygulamasi.databinding.ActivityMapsBinding;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private List<Ilan> ilanList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ilanList = new ArrayList<>();
        ilanList.add(new Ilan("Ahmet Yılmaz", "İstanbul Üniversitesi", 22, "Erkek", "Bilgisayar Mühendisliği", "İzmir", 41.0082, 28.9784));
        ilanList.add(new Ilan("Elif Kaya", "Boğaziçi Üniversitesi", 20, "Kadın", "Endüstri Mühendisliği", "Ankara", 41.0840, 29.0510));
        ilanList.add(new Ilan("Mehmet Şahin", "İTÜ", 23, "Erkek", "Makine Mühendisliği", "Bursa", 41.1010, 29.0260));
        ilanList.add(new Ilan("Ayşe Özdemir", "Koç Üniversitesi", 21, "Kadın", "Tıp", "Adana", 41.1332, 29.0806));
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng userLocation = new LatLng(41.015137, 28.979530);  // İstanbul
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 12));

        for (Ilan ilan : ilanList) {
            LatLng ilanKonumu = new LatLng(ilan.getLatitude(), ilan.getLongitude());
            float[] distance = new float[1];
            Location.distanceBetween(userLocation.latitude, userLocation.longitude, ilanKonumu.latitude, ilanKonumu.longitude, distance);

            if (distance[0] < 5000) {
                mMap.addMarker(new MarkerOptions().position(ilanKonumu)
                        .title(ilan.getIsim())
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
            } else {
                mMap.addMarker(new MarkerOptions().position(ilanKonumu)
                        .title(ilan.getIsim())
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
            }
        }
    }
}